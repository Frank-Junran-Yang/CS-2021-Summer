Create a school system

Student application (first name, lastname, username, password, countryofOrigin)
- Students can register
- Student can login
- Once loged in:
    - Can see all students (table)
    - Can see specific student
    - Can edit info about me
    - Delete account

