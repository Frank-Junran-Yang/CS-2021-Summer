from django.contrib import admin
from .models import Lesson

admin.site.register(Lesson)
# Register your models here.
