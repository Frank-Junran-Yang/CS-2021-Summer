from django.contrib import admin
from .models import Account, Friendship

admin.site.register(Account)
admin.site.register(Friendship)
# Register your models here.
